<form method="POST">
	<p>
		Name: <input type="text" name="name" />
	</p>
	<p>
		Country: <input type="text" name="country" />
	</p>
	<input type="submit" />
</form>