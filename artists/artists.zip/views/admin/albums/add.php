<form method="POST">
	<p>
		Name: <input type="text" name="name" />
	</p>
	<p>
		Year: <input type="text" name="year" />
	</p>
	<p>
		Artist ID: <input type="text" name="artist_id" />
	</p>
	<input type="submit" />
</form>