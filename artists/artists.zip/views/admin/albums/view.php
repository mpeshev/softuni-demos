<table>
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Year</th>
		<th>Artist ID</th>
	</tr>
	<tr>
		<td><?php echo $album['id']; ?></td>
		<td><?php echo $album['name']; ?></td>
		<td><?php echo $album['year']; ?></td>
		<td><?php echo $artist['name']; ?></td>
	</tr>
</table>