<?php include_once DX_ROOT_DIR . '/views/elements/header.php'; ?>
<h2>Admin Area - Security Personnel</h2>
<?php include_once $template_name; ?>
<?php include_once DX_ROOT_DIR . '/views/elements/footer.php'; ?>