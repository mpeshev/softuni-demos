<?php
define( 'DX_URL', 'http://localhost/artists/' );